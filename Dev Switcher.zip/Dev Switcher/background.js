chrome.runtime.onMessage.addListener(function(request, sender, sendResponse) {
  const devUrl = "https://dev17.mostbet.com";
  const prodUrl = "https://mostbet.com";
  const newDomainUrl = "https://ntcdl0i.com"; 

  if (request.action === "setCookie") {
    chrome.cookies.set({
      url: devUrl,
      name: "PW_DEV",
      value: request.value
    }, function(cookie) {
      console.log("Кука установлена:", cookie);
    });
  } else if (request.action === "removeCookie") {
    chrome.cookies.remove({ url: devUrl, name: "PW_DEV" }, function(details) {
      console.log("Кука удалена:", details);
    });
  } else if (request.action === "setPwEnabledCookie") {
    chrome.cookies.set({
      url: prodUrl,
      name: "pw_enabled",
      value: "1"
    }, function(cookie) {
      console.log("Кука pw_enabled установлена на mostbet.com:", cookie);
    });

    chrome.cookies.set({
      url: newDomainUrl,
      name: "pw_enabled",
      value: "1"
    }, function(cookie) {
      console.log("Кука pw_enabled установлена на ntcdl0i.com:", cookie);
    });
  }
});
